import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;

import com.paulhammant.ngwebdriver.ByAngular;
import com.paulhammant.ngwebdriver.NgWebDriver;

public class AngularSelenium {

	
	@Test
	public static void init() {    
		System.setProperty("webdriver.chrome.driver", "C:\\ChromeDriver21\\chromedriver.exe");
		ChromeDriver driver = new ChromeDriver();
		WebDriverWait waitdriver = new WebDriverWait(driver, 20);
		driver.get("http://localhost:4200/view-student");
		NgWebDriver ngDriver = new NgWebDriver((JavascriptExecutor)driver );
		ngDriver.waitForAngularRequestsToFinish();
		driver.findElement(ByAngular.buttonText("add-student")).click();
		
		driver.findElement(ByAngular.buttonText("user")).sendKeys("Peter");
		driver.findElement(ByAngular.buttonText("email")).sendKeys("3odas@web.de");
		driver.findElement(ByAngular.buttonText("Branch")).isSelected();
		driver.findElement(ByAngular.buttonText("Accept")).click();
		
		driver.quit();
	}
}
